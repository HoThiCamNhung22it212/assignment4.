<!DOCTYPE html>
<html>

<head>
    <title>Rating</title>
    <meta charset="utf-8">
    <link href="template/css.css" type="text/css" rel="stylesheet">
</head>

<body>
    <div id="container">
        <header>
            <h1><a href="index.php">COMPUTER ABC</a></h1>
        </header>
        <div id="main-wrapper">
            <?php echo $html ?>
        </div>
        <footer>
        </footer>
    </div>
</body>

</html>